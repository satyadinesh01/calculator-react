import { useState } from 'react';
import './App.css';
import Keypad from './keypad';
 
function App() {
    let [input , setInput] = useState("")
    function handleClick(value){
        setInput(input + value)
    }

    function calculate(value){
        let outputval = eval(input)
        setInput(outputval)
    }

    function handleClear(){
        setInput("")
    }

 return (
   <div className="container">
    	<p className='head'>CALCULATOR APP USING REACT JS</p>
        <div className='calculator'>
            <input type='text' value={input} className='output'/>
        </div>
        <Keypad handleClick={handleClick}  handleClear={handleClear} calculate={calculate}/>
   </div>
 );
}
 
export default App;